#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
//    npc.load(filePath);
    npc.load(filePath);
    x = ofGetWidth() / 2;
    y = ofGetHeight() - 1 - npc.getHeight()+50;
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){

    npc.draw(x, y);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    switch (key) {
        case('w'):
            if(y>0){
                y-=step;
            }
            break;
        case('s'):
            break;
        case('a'):
            if(x > 0) {
                x -= step;
            }
            break;
        case('d'):
            if(x < ofGetWidth() - 1) {
                x += step;
            }
            break;
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    switch(key){
        case('w'):
            if(y>0){
                y = ofGetHeight() - 1 - npc.getHeight()-30;
            
            }
            break;
            
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

bool ofApp::disappear() {
    /*
     for (i = 0 ; i <= coinList.size; i++ ) {
        if(collision (coin) {
            coin.play = false;
            //
        }
     }
    */
}
